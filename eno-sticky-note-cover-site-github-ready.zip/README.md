# 李伊诺作品集｜便利贴拼贴封面版

## 文件结构
```text
eno-sticky-note-cover-site/
├── index.html
└── assets/
    ├── avatar-cover.jpg       # 已放入你的个人照片
    └── 李伊诺-简历.pdf         # 后续可自行补充
```

## 说明
这版封面参考“小红书便利贴拼贴风”：
- 人物照片由多个纸片碎块拼成
- 周围便利贴写入简历能力关键词
- 便利贴有轻微风吹浮动
- 背景为浅灰纸张肌理 + 大面积留白
- 下方保留 Selected Work 和 About 区域，方便继续扩展作品集

## 上传到 GitHub
上传 `index.html` 和 `assets` 文件夹到仓库根目录即可。
